# React + Node + MySQL Login and Registration with Protected Routes

**support me:** https://buymeacoffee.com/codewithyousaf

![react js](https://github.com/user-attachments/assets/aba88a1d-bdca-4e20-beea-c816a6dae31e)
