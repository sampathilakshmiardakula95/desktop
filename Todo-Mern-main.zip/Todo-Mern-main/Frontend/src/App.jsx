import TodoApp from "./components/TodoApp";

export default function App() {
  return <TodoApp/>;
}
